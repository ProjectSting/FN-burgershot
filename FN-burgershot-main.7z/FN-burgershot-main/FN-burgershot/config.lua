config = {
    ['precos'] = {
        [1] = {
            preco = 5000,
        },
        [2] = {
            preco = 1000,
        },
        [3] = {
            preco = 500,
        },
        [4] = {
            preco = 100,
        },
    },
}

config.Items = {
    label = "BS drinks",
    slots = 10,
    items = {
        [1] = {
            name = "water_bottle",
            price = 0,
            amount = 100,
            slot = 1,
        }
    }
}

config.bsjob = "burgershot"